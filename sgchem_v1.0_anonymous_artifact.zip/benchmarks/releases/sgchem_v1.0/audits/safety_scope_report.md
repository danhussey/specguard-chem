# Safety Scope Report

task count scanned: 656
agent-visible forbidden term matches: 0
medicinal chemistry allowed framing confirmation: yes

Out-of-scope claim terms are checked only in agent-visible task text.
